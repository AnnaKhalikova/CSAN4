﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace TcpServer
{
    class Server
    {
        private static int PORT = 5555;
        private static int SIZE = 8192;
        private static int LEN = 10;

        static void Main(string[] args)
        {
            try
            {
                Socket listener = new Socket(
                    AddressFamily.InterNetwork, SocketType.Stream,
                    ProtocolType.Tcp);
                IPEndPoint endPoint = new IPEndPoint(
                    IPAddress.Any, PORT);
                listener.Bind(endPoint);
                listener.Listen(LEN);
                Run(listener);
            }
            catch (SocketException exception)
            {
                Console.WriteLine("I have a problem\n" + exception);
            }
            finally
            {
                Console.Write("Press \'Enter\' to exit: ");
                Console.ReadLine();
            }
        }

        private static void Run(Socket listener)
        {
            while (true)
            {
                Socket socket = listener.Accept();
                TalkWithClient(socket);
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
        }

        private static void TalkWithClient(Socket socket)
        {
            int floorPort, ceilPort;
            while (true)
            {
                floorPort = 1;
                ceilPort = 65535;
                floorPort = GetIntegerFromClient(socket, floorPort);
                ceilPort = GetIntegerFromClient(socket, ceilPort);
                SendMessage(socket, GetPortTable(floorPort, ceilPort));
                if (ReceiveMessage(socket).IndexOf("<end>") > -1) break;
            }
        }

        private static int GetIntegerFromClient(Socket socket, int defaultNum)
        {
            string strnum = ReceiveMessage(socket);
            int num = defaultNum;
            int.TryParse(strnum, out num);
            return num;
        }

        private static string GetPortTable(int a, int b)
        {
            StringBuilder table = new StringBuilder();
            Socket checkPort;
            IPEndPoint endPoint;
            if (a > b)
            {
                swap(ref a, ref b);
            }

            for (int i = a; i <= b; i++)
            {
                try
                {
                    checkPort = new Socket(AddressFamily.InterNetwork,
                        SocketType.Stream, ProtocolType.Tcp);
                    endPoint = new IPEndPoint(IPAddress.Any, i);
                    checkPort.Bind(endPoint);
                    checkPort.Close();     
                }
                catch (SocketException e)
                {
                    table.Append("Port: ");
                    table.Append(i);
                    table.Append("\n");
                }
            }

            return table.ToString();
        }

        private static void SendMessage(Socket socket, string message)
        {
            byte[] byteSend = new byte[SIZE];
            byteSend = Encoding.ASCII.GetBytes(message);
            socket.Send(byteSend);
        }

        private static string ReceiveMessage(Socket socket)
        {
            string message;
            byte[] byteReceive = new byte[SIZE];
            int lenReceive = socket.Receive(byteReceive);
            message = Encoding.ASCII.GetString(byteReceive, 0, lenReceive);
            return message;
        }

        private static void swap(ref int a, ref int b)
        {
            a ^= b;
            b ^= a;
            a ^= b;
        }
    }
}
