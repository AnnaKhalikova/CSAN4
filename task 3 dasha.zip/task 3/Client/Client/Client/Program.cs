﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace TcpClient
{
    class Client
    {
        private static int SIZE = 8192;

        static void Main(string[] args)
        {
            try
            {
                Console.Write("Server port: ");
                int port = int.Parse(Console.ReadLine());
                Socket socket = new Socket(
                    AddressFamily.InterNetwork,
                    SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint endPoint = new IPEndPoint(
                    IPAddress.Loopback, port);
                socket.Connect(endPoint);
                Run(socket);
                socket.Shutdown(SocketShutdown.Send);
                socket.Close();
            }
            catch (SocketException exception)
            {
                Console.WriteLine("I have a problem\n" + exception);
            }
            finally
            {
                Console.Write("Press \'Enter\' to exit: ");
                Console.ReadLine();
            }
        }

        private static void Run(Socket socket)
        {
            string answer = "";
            while (answer.IndexOf("<end>") == -1)
            {
                Console.Write("Begin: ");
                SendMessage(socket, Console.ReadLine());
                Console.Write("Finish: ");
                SendMessage(socket, Console.ReadLine());
                Console.WriteLine(ReceiveMessage(socket));
                Console.Write("Send <end> to exit: ");
                answer = Console.ReadLine();
                SendMessage(socket, answer);
            }
        }

        private static void SendMessage(Socket socket, string message)
        {
            byte[] byteSend = new byte[SIZE];
            byteSend = Encoding.ASCII.GetBytes(message);
            socket.Send(byteSend);
        }

        private static string ReceiveMessage(Socket socket)
        {
            string message;
            byte[] byteReceive = new byte[SIZE];
            int lenReceive = socket.Receive(byteReceive);
            message = Encoding.ASCII.GetString(byteReceive, 0, lenReceive);
            return message;
        }
    }
}
